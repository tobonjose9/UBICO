package com.doo.ubico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UbicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UbicoApplication.class, args);
	}

}
