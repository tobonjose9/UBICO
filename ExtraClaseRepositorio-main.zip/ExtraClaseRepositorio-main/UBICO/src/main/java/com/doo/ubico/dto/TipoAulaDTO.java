package com.doo.ubico.dto;public class TipoAulaDTO {
}
