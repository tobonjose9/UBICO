package com.doo.ubico.data.dao;public class BloqueDAO {
}
