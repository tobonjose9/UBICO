package com.doo.ubico.data.dao;public interface AulaDAO {
}
